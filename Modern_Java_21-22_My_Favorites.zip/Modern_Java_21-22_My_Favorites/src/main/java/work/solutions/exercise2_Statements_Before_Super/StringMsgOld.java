package work.solutions.exercise2_Statements_Before_Super;

/**
 * Beispielprogramm für die Workshops "Best of Java 11 - 21/22" und das
 * Buch "Java – Die Neuerungen in Version 17 LTS, 18 und 19"
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021/22/23/24 by Michael Inden
 */
public class StringMsgOld extends PlainByteMsg
    {
        public StringMsgOld(final String payload) {
        super(convertToByteArray(payload));
    }

        // Auxiliary method: Null-Prüfung, Verarbeitung und Konvertierung gemixt
        private static byte[] convertToByteArray(final String payload) {
            if (payload == null)
                throw new IllegalArgumentException("payload should not be null");

            String transforemedPayload = heavyStringTransformation(payload);
            return switch (transforemedPayload) {
                case "AA" -> new byte[]{1, 2, 3, 4};
                case "BBBB" -> new byte[]{7, 2, 7, 1};
                default -> transforemedPayload.getBytes();
            };
        }

        private static String heavyStringTransformation(String input) {
            return input.repeat(2);
        }

    public static void main(String[] args) {
        System.out.println(new StringMsgOld("A"));
        System.out.println(new StringMsgOld("BB"));
        System.out.println(new StringMsgOld("HELLO SOPHIE"));
        System.out.println(new StringMsgOld(null));
    }
}