package java22.jep459_String_Templates;

public class InvalidOrderException extends RuntimeException {
    public InvalidOrderException(String errorMessage) {
        super(errorMessage);
    }
}
