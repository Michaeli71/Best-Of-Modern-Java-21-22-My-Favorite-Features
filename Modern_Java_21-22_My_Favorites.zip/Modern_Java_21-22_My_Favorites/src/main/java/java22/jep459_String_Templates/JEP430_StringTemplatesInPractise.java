package java22.jep459_String_Templates;

import java.time.LocalDate;

/**
 * Beispielprogramm für die Workshops "Best of Java 11 - 21" und das
 * Buch "Java – Die Neuerungen in Version 17 LTS, 18 und 19"
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021/22/23/24 by Michael Inden
 */
public class JEP430_StringTemplatesInPractise {
    public static void main(String[] args) {

        processOrderOldStyle(42, 4711, 1, LocalDate.now());
        // processOrderOldStyle(42L, 4711L, -1, LocalDate.now());
        // processOrderOldStyle(42L, 4711L, 1, LocalDate.now().minusDays(1));

        processOrderNewStyle(42, 4711, 1, LocalDate.now());
        // processOrderNewStyle(42L, 4711L, -1, LocalDate.now());
        processOrderNewStyle(42, 4711, 1, LocalDate.now().minusDays(1));
    }

    public static void processOrderOldStyle(int orderId, int productId, int quantity, LocalDate orderDate) {
        if (quantity <= 0) {
            String errorMessage = "Invalid order quantity: " + quantity + " for product '" + getProductFor(productId) + "', order ID " + orderId;
            throw new InvalidOrderException(errorMessage);
        }

        if (orderDate.isBefore(LocalDate.now())) {
            String errorMessage = "Invalid order date: " + orderDate + " for product '" + getProductFor(productId) + "', order ID " + orderId;
            throw new InvalidOrderException(errorMessage);
        }

        // ...

        printOrderConfirmationOldStyle(orderId, productId, quantity, orderDate);
        printOrderConfirmationOldStyleV2(orderId, productId, quantity, orderDate);
    }

    private static String getProductFor(long productId) {
        return "MBP M3 MAX";
    }

    public static void processOrderNewStyle(int orderId, int productId, int quantity, LocalDate orderDate) {
        if (quantity <= 0) {
            var errorMessage = STR."Invalid order quantity: \{quantity} for " +
                    STR."product '\{getProductFor(productId)}', " +
                    STR."order ID \{orderId}";
            throw new InvalidOrderException(errorMessage);
        }

        if (orderDate.isBefore(LocalDate.now())) {
            var errorMessage = STR."Invalid order date: \{orderDate} for " +
                    STR."product '\{getProductFor(productId)}', " +
                    STR."order ID \{orderId}";
            throw new InvalidOrderException(errorMessage);
        }

        // ...
        printOrderConfirmationNewStyle(orderId, productId, quantity, orderDate);
    }

    private static void printOrderConfirmationOldStyle(long orderId, long productId,
                                                       int quantity, LocalDate orderDate) {
        System.out.println("Your order id is " + orderId + "\n" +
                "On " + orderDate + " you ordered\n" +
                "product '" + getProductFor(productId) + "'\n" +
                "quantity " + quantity);
    }

    private static void printOrderConfirmationOldStyleV2(long orderId, long productId,
                                                         int quantity, LocalDate orderDate) {
        System.out.println("""
                Your order id is %d
                On %tF you ordered
                product '%s'
                quantity %d""".formatted(orderId, orderDate, getProductFor(productId), quantity));
    }

    private static void printOrderConfirmationNewStyle(int orderId, int productId,
                                                       int quantity, LocalDate orderDate) {
        System.out.println(STR."""
                           Your order id is \{orderId}
                           On \{orderDate} you ordered
                           product '\{getProductFor(productId)}'
                           quantity \{quantity}""");
    }
}
