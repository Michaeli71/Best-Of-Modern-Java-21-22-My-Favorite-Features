package java22.jep447_Statements_Before_Super;

/**
 * Beispielprogramm für die Workshops "Best of Java 11 - 21/22" und das
 * Buch "Java – Die Neuerungen in Version 17 LTS, 18 und 19"
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021/22/23/24 by Michael Inden
 */
public class StringMsg extends PlainByteMsg {

    public StringMsg(String payload) {
        super(convertToByteArray(payload));
    }

    // Auxiliary method
    private static byte[] convertToByteArray(String payload) {
        if (payload == null)
            throw new IllegalArgumentException("payload should not be null");

        return switch (payload) {
            case "TYPE_A" -> new byte[] { 1, 2, 3, 4 };
            case "TYPE_B" -> new byte[] { 7, 2, 7, 1 };
            default -> payload.getBytes();
        };
    }

    public static void main(String[] args) {
        new StringMsg("TYPE_A");
        new StringMsg("TYPE_B");
        new StringMsg("HELLO SOPHIE");
    }
}