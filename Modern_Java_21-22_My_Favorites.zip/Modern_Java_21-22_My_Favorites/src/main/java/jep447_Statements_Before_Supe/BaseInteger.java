package jep447_Statements_Before_Supe;

/**
 * Beispielprogramm für die Workshops "Best of Java 11 - 21/22" und das
 * Buch "Java – Die Neuerungen in Version 17 LTS, 18 und 19"
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021/22/23/24 by Michael Inden
 */
class BaseInteger
{
    private final long value;

    BaseInteger(final long value) {
        this.value = value;
    }

    public long getValue() {
        return value;
    }

    public static void main(final String[] args)
    {
        new BaseInteger(4711);
    }
}