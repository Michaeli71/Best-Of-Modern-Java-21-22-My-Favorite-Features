package all_time_favorites;

import java.time.DayOfWeek;
import java.time.Month;

/**
 * Beispielprogramm für den Workshop "Java 11 bis 20" / das Buch "Java 21 LTS – die Neuerungen"
 *
 * @author Michael Inden
 * <p>
 * Copyright 2023 by Michael Inden
 */
public class SwitchExample {

    public static void main(String[] args) {

        System.out.println(dayNameToLetterCount());
        System.out.println(monthToName(Month.FEBRUARY));
    }

    static int dayNameToLetterCount() {
        DayOfWeek day = DayOfWeek.FRIDAY;
        int numLetters = switch (day) {
            case MONDAY, FRIDAY, SUNDAY -> 6;
            case TUESDAY -> 7;
            case THURSDAY, SATURDAY -> 8;
            case WEDNESDAY -> 9;
        };
        return numLetters;
    }

    static String monthToName(final Month month) {
        return switch (month) {
            case JANUARY -> "January";
            default -> "N/A"; // hier KEIN Fall Through
            case FEBRUARY -> "February";
            case MARCH -> "March";
            case JULY -> "July";
        };
    }

    enum Color {RED, GREEN, BLUE, YELLOW, ORANGE}


    public static void switchYieldReturnsValue(Color color) {
        int numOfChars = switch (color) {
            case RED:
                yield 3;
            case GREEN: yield 5;
            case YELLOW, ORANGE:
                yield 6;
            default:
				throw new IllegalArgumentException("Unexpected color: " + color);
        };

        System.out.println(STR."color: \{color} ==> \{numOfChars}");
    }

}
