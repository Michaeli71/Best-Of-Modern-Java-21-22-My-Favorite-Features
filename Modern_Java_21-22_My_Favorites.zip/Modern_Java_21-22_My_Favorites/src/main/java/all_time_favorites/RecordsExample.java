package all_time_favorites;

import java.util.List;

public class RecordsExample {

    record MyPoint(int x, int y) {
    }

    record IntStringReturnValue(int code, String info) {
    }

    record IntListReturnValue(int code, List<String> values) {
    }

    record ReturnTuple(String first, String last, int amount) {
    }

    record CompoundKey(String name, int age) {
    }

    IntStringReturnValue calculateTheAnswer() {
        // Some complex stuff here
        return new IntStringReturnValue(42, "the answer");
    }

    IntListReturnValue calculate(CompoundKey inputKey) {
        // Some complex stuff here
        return new IntListReturnValue(201, List.of("This", "is", "a", "complex", "result"));
    }

    // Pairs
    record IntIntPair(int first, int second) {
    }

    ;

    record StringIntPair(String name, int age) {
    }

    ;

    record Pair<T1, T2>(T1 first, T2 second) {
    }

    ;

    record Top3Favorites(String top1, String top2, String top3) {
    }

    ;

    record CalcResultTuple(int min, int max, double avg, int count) {
    }

    ;
}
