package all_time_favorites;

/**
 * Beispielprogramm für den Workshop "Java 11 bis 20" / das Buch "Java 21 LTS – die Neuerungen"
 *
 * @author Michael Inden
 * <p>
 * Copyright 2023 by Michael Inden
 */
public class TextBlocksExample {

    public static void main(String[] args) {

        String multiLineString = """
            THIS IS
            A MULTI
            LINE STRING
            WITH A BACKSLASH \\
            """;
        System.out.println(multiLineString);


        String jsonObj = """
                {
                    "name": "Mike",
                    "birthday": "1971-02-07",
                    "comment": "Text blocks are nice!"
                }
                """;

        System.out.println(jsonObj);

        String text = """
                This is a string splitted in several smaller \
                jjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjj \
                jjjjjjjjjjjjjjjjjjjjjjjj \
                jjjjjjjjjjjj strings""";

        System.out.println(text);
        System.out.println(text.getClass());
    }
}
