package jep459_String_Templates;

import static java.util.FormatProcessor.FMT;

/**
 * Beispielprogramm für die Workshops "Best of Java 11 - 21" und das
 * Buch "Java – Die Neuerungen in Version 17 LTS, 18 und 19"
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021/22/23/24 by Michael Inden
 */
public class JEP430_StringTemplates_FMT {
    public static void main(final String[] args) {
        alternativeStringProcessors();
    }

    private static void alternativeStringProcessors() {
        int x = 47;
        int y = 11;
        String calculation1 = FMT."%6d\{x} + %6d\{y} = %6d\{x + y}";
        System.out.println("fmt calculation 1: " + calculation1);

        float base = 3.0f;
        float addon = 0.1415f;
        String calculation2 = FMT."%2.4f\{base} + %2.4f\{addon}" +
                FMT." = %2.4f\{base + addon}";
        System.out.println("fmt calculation 2: " + calculation2);

        String calculation3 = FMT."Math.PI * 1.000 = %4.6f\{Math.PI * 1000}";
        System.out.println("fmt calculation 3: " + calculation3);
    }
}
