package jep459_String_Templates;

public class InvalidOrderException extends RuntimeException {
    public InvalidOrderException(String errorMessage) {
        super(errorMessage);
    }
}
