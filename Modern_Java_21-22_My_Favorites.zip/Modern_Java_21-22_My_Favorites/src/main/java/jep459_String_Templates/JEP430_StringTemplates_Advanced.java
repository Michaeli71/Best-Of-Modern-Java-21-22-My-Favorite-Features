package jep459_String_Templates;

import java.util.FormatProcessor;
import java.util.Locale;

/**
 * Beispielprogramm für die Workshops "Best of Java 11 - 21" und das
 * Buch "Java – Die Neuerungen in Version 17 LTS, 18 und 19"
 *
 * @author Michael Inden
 *         <p>
 *         Copyright 2021/22/23 by Michael Inden
 */
public class JEP430_StringTemplates_Advanced {
    public static void main(final String[] args) {
        String name = "Michael";
        int age = 53;
        System.out.println(STR."Hello \{name}. You are \{age} years old.");

        var myProc = new MyProcessor();
        System.out.println(myProc."Hello \{name}. You are \{age} years old.");

        // localized
        var thaiLocale = Locale.forLanguageTag("th-TH-u-nu-thai");
        FormatProcessor thaiFMT = FormatProcessor.create(thaiLocale);
        int x = 10;
        int y = 20;
        String result = thaiFMT."%4d\{x} + %4d\{y} = %5d\{x + y}";
        System.out.println(result);
    }

static class MyProcessor implements StringTemplate.Processor<String, IllegalArgumentException> {
    @Override
    public String process(StringTemplate stringTemplate) throws IllegalArgumentException {
        System.out.println("\n-- process() --");
        System.out.println("info fragments:" + stringTemplate.fragments());
        System.out.println("info values: " + stringTemplate.values());
        System.out.println("info interpolate: " + stringTemplate.interpolate());
        System.out.println();

        var adjustedValues = stringTemplate.values().stream().map(str -> ">>" + str + "<<").toList();

        return StringTemplate.interpolate(stringTemplate.fragments(), adjustedValues);
    }
}
}
