package java21_final.virtuals_threads;
import java.time.Duration;
import java.util.concurrent.Executors;

/**
 * Beispielprogramm für die Workshops "Best of Java 11 - 21" und das
 * Buch "Java – Die Neuerungen in Version 17 LTS, 18 und 19"
 *
 * @author Michael Inden
 *         <p>
 *         Copyright 2021/22/23/24 by Michael Inden
 */
public class VirtualThreadsExample
{
    public static void main(String[] args)
    {
    	System.out.println("Start");

        try (var executor = Executors.newVirtualThreadPerTaskExecutor())
        //try (var executor = Executors.newCachedThreadPool())
        {
            for (int  i = 0; i < 10_000_000; i++)
            {
                final int pos = i;
                executor.submit(() -> {
                    Thread.sleep(Duration.ofSeconds(5));
                    return pos;
                });
            }
        }
        // executor.close() is called implicitly, and waits for task completion
        System.out.println("End");
    }
}
