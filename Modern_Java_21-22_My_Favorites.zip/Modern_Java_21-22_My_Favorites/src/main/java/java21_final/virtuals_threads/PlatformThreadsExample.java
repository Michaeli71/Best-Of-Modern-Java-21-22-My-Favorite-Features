package java21_final.virtuals_threads;

import java.time.Duration;
import java.util.concurrent.Executors;

/**
 * Beispielprogramm für die Workshops "Best of Java 11 - 21" und das
 * Buch "Java – Die Neuerungen in Version 17 LTS, 18 und 19"
 *
 * @author Michael Inden
 *         <p>
 *         Copyright 2021/22/23 by Michael Inden
 */
public class PlatformThreadsExample
{
    public static void main(final String[] args)
    {
        System.out.println("Start");

        try (var executor = Executors.newCachedThreadPool())
        {
            // Demo: 1_000 // 10_000 // 100_000
            for (int i = 0; i < 1_000; i++)
            {
                final int pos = i;
                executor.submit(() -> {
                    Thread.sleep(Duration.ofSeconds(5));
                    return pos;
                });
            }
        }

        // executor.close() is called implicitly, and waits
        System.out.println("End");
    }
}
