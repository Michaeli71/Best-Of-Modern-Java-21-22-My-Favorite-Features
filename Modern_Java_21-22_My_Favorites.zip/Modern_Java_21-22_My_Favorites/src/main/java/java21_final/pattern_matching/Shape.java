package java21_final.pattern_matching;

interface Shape {}

record Rectangle(int x, int y, int width, int height) implements Shape {}

record Triangle(int area) implements Shape {}