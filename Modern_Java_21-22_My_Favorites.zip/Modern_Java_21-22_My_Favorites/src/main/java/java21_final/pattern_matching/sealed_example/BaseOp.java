package java21_final.pattern_matching.sealed_example;

sealed abstract class BaseOp permits Add, Sub {}

final class Add extends BaseOp {}

final class Sub extends BaseOp {}