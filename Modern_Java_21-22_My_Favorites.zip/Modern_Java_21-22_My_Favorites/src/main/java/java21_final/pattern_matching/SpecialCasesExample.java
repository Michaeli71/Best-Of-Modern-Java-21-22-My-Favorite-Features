package java21_final.pattern_matching;

public class SpecialCasesExample {

    public static void main(String[] args) {
        specialCasesAndRanges(2);
        specialCasesAndRanges(71);
        specialCasesAndRanges(-13);
    }
    static void specialCasesAndRanges(final Integer value)
    {
        switch (value)
        {
            case 0, 1, 2, 3 -> System.out.println("Special cases 0, 1, 2 or 3");
            case Integer i when i > 3 -> System.out.println("i > 3");
            case Integer i -> System.out.println("all remaining integers");
        }
    }
}
